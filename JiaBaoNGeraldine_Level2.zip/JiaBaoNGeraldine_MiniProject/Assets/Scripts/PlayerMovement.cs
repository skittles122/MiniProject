﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerMovement : MonoBehaviour
{
    public static bool GameOver;


    private GameManager gameController;
    private Rigidbody rb;
    private float verticalMovement;

    public GameObject gameControllerObj;

    public float speed;

    public Slider healthSlider;
    public Image healthSliderImage;

    public int maxHealth;
    public static int currentHealth;

    private void Awake()
    {
        gameController = gameControllerObj.GetComponent<GameManager>();
    }

    void Start()
    {
        currentHealth = maxHealth;
        healthSlider.maxValue = maxHealth;
        healthSlider.value = maxHealth;

        rb = this.gameObject.GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {
        float moveHorizontal = Input.GetAxis("Horizontal");

        float moveVertical = Input.GetAxis("Vertical");

        Vector3 movement = new Vector3(moveHorizontal, moveVertical, 0);

        rb.velocity = (movement * speed);
    }

    private void UpdateHealthSlider()
    {
        healthSlider.value = currentHealth;
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "Obstacle")
        {
            currentHealth = currentHealth - 10;
            gameController.CheckGameOver(currentHealth);

            UpdateHealthSlider();

            GameOver = false;
        }
        if (other.gameObject.tag == "PowerUp")
        {
            currentHealth = currentHealth + 10;
            if (currentHealth > maxHealth)
            {
                currentHealth = maxHealth;
            }

            UpdateHealthSlider();
        }
    }
}
