﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ResetPlayerData : ScoreData
{
    public void ResetData()
    {
        PlayerPrefs.DeleteAll();
        score = 0;
    }
}
