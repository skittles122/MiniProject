﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnerScript : MonoBehaviour
{
    public GameObject Obstacle;

    public int spawnNumber;

    public float positionY;
    // Start is called before the first frame update
    void Start()
    {
        InvokeRepeating("Spawner", 1f, 1f);
    }
    
    public GameObject Spawner()
    {
        spawnNumber = 1;

        positionY = Random.Range(-3.7f, 3.75f);

        this.transform.position = new Vector3(transform.position.x, positionY, transform.position.z);

        if(spawnNumber == 1)
        {
            GameObject tempGameObject = Instantiate(Obstacle, transform.position, transform.rotation);
            return tempGameObject;
        }

        return null;
    }
}