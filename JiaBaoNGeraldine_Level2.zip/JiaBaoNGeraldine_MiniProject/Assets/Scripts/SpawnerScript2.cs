﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnerScript2 : MonoBehaviour
{
    public GameObject PowerUp;

    public int spawnNumber;

    public float positionY;
    // Start is called before the first frame update
    void Start()
    {
        InvokeRepeating("Spawner", 15f, 1f);
    }

    // Update is called once per frame
    void Update()
    {
    }
    public void Spawner()
    {
        spawnNumber = Random.Range(1, 4);

        positionY = Random.Range(-4, 4);

        this.transform.position = new Vector3(transform.position.x, positionY, transform.position.z);

        if (spawnNumber == 1)
        {
            Instantiate(PowerUp, transform.position, transform.rotation);
        }
    }
}
