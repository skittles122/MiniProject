﻿using System.Collections;
using System.Security.Cryptography;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.TestTools;


namespace Tests
{
    public class TestSuite
    {
        private GameObject game;

        [SetUp]
        public void SetUp()
        {
            game = MonoBehaviour.Instantiate(Resources.Load<GameObject>("Prefabs/Game"));

        }

        [TearDown]
        public void Teardown()
        {
            // destroy the whole game prefab //
            Object.Destroy(game);
        }

        [UnityTest]
        public IEnumerator CheckSpawner()
        {
            GameObject Spawner = GameObject.Find("Spawner");
            yield return new WaitForSeconds(0.1f);

            Assert.IsTrue(Spawner);
        }

        [UnityTest]
        public IEnumerator CheckPlayer()
        {
            PlayerMovement playerScript = GameObject.Find("Player").GetComponent<PlayerMovement>();
            GameObject Player = GameObject.FindGameObjectWithTag("Player");
            yield return new WaitForSeconds(3f);

            Assert.IsFalse(PlayerMovement.GameOver);
        }

        [UnityTest]
        public IEnumerator CheckPlayerHealth()
        {
            PlayerMovement playerScript = GameObject.Find("Player").GetComponent<PlayerMovement>();
            GameObject Player = GameObject.FindGameObjectWithTag("Player");
            SpawnerScript Spawnscript = GameObject.Find("Spawner").GetComponent<SpawnerScript>();
            GameObject Obstacle = Spawnscript.Spawner();
            yield return new WaitForSeconds(3f);

            Obstacle.transform.position = Player.transform.position;
            yield return new WaitForSeconds(1f);

            Assert.Negative(PlayerMovement.currentHealth);
        }
    }
}
