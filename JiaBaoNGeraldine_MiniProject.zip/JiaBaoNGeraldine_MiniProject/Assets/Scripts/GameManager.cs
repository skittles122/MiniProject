﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    private ScoreData scoreData;

    public GameObject pausedCanvas;
    public GameObject gameOverCanvas;
    public GameObject quitConfirmCanvas;

    public Text endScoreText;
    public Text endHighScoreText;
    public Text newHighScoreText;

    private AudioSource[] audioSource;
    private AudioSource death;

    public string mainGameScene;
    public string mainMenuScene;

    private bool gameOver;
    private bool paused;

    // Start is called before the first frame update
    void Start()
    {
        Time.timeScale = 1;
        gameOver = false;
        paused = false;

        scoreData = gameObject.GetComponent<ScoreData>();
        newHighScoreText.enabled = false;

        audioSource = gameObject.GetComponents<AudioSource>();
        death = audioSource[0];
    }

    // Update is called once per frame
    void Update()
    {
        if(gameOver)
        {
            return;
        }
        if(Input.GetKeyDown(KeyCode.P))
        {
            if(pausedCanvas.activeSelf)
            {
                ClosePauseCanvas();
            }
            else
            {
                OpenPauseCanvas();
            }
        }
        if(Input.GetKeyDown(KeyCode.Escape))
        {
            //QuitConfirm();
        }
    }

    private void PauseGame()
    {
        Time.timeScale = 0;
        paused = true;
    }

    private void UnPauseGame()
    {
        Time.timeScale = 1;
        paused = false;
    }

    public void OpenPauseCanvas()
    {
        PauseGame();
        pausedCanvas.SetActive(true);
    }

    public void ClosePauseCanvas()
    {
        UnPauseGame();
        pausedCanvas.SetActive(false);
    }

    public void CheckGameOver(int currentHealth)
    {
        if(currentHealth<= 0)
        {
            death.Play();
            gameOver = true;
            Time.timeScale = 0;
            SetGameOverScreen();
        }
    }

    public void SetGameOverScreen()
    {
        gameOverCanvas.SetActive(true);
        int score = scoreData.getScore();

        scoreData.updateHighScore();
        int highscore = scoreData.getHighScore();

        endScoreText.text = "Score: " + score.ToString();
        endHighScoreText.text = "HighScore: " + highscore.ToString();
        if(score == highscore)
        {
            newHighScoreText.enabled = true;
        }
    }

    public void RestartScene()
    {
        SceneManager.LoadScene(mainGameScene);
    }

    public void ExitToMenu()
    {
        UnPauseGame();
        SceneManager.LoadScene(mainMenuScene);
    }

    public void Continue(GameObject canvas)
    {
        canvas.SetActive(false);

        if(pausedCanvas.activeSelf || gameOverCanvas.activeSelf)
        {
            return;
        }

        UnPauseGame();
    }

    public void QuitConfirm()
    {
        quitConfirmCanvas.SetActive(true);
        if(!paused)
        {
            PauseGame();
        }
    }
    public bool isPaused()
    {
        return paused;
    }

    public bool isGameOver()
    {
        return gameOver;
    }
}
