﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    public GameObject gameControllerObj;
    private GameManager gameController;

    // Start is called before the first frame update
    public float speed;

    private Rigidbody rb;

    private float verticalMovement;

    public float Health;

    private void Awake()
    {
        gameController = gameControllerObj.GetComponent<GameManager>();
    }

    void Start()
    {
        rb = this.gameObject.GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {
        float moveHorizontal = Input.GetAxis("Horizontal");

        float moveVertical = Input.GetAxis("Vertical");

        Vector3 movement = new Vector3(moveHorizontal, moveVertical, 0);

        rb.velocity = (movement * speed);
    }
    private void OnCollisionEnter(Collision collision)
    {
        if(collision.gameObject.tag == "Obstacle")
        {
            Health = -10;
            //idk how settle the slider... haha
        }
        if (collision.gameObject.tag == "PowerUp")
        {
            Health = +10;
            //idk how u settle the powerup also
        }
    }
}
