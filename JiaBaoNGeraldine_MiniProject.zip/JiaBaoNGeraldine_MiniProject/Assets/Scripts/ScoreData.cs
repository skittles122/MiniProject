﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ScoreData : MonoBehaviour
{
    private int score;
    private int prevHighScore;
    public int scorePerSecond = 50;

    private string highScorekey = "High Score";

    // Start is called before the first frame update
    void Start()
    {
        score = 0;
        prevHighScore = PlayerPrefs.GetInt(highScorekey, 0);
    }

    public int getScore()
    {
        return score;
    }

    public void updateScore()
    {
        score += Mathf.RoundToInt(Time.deltaTime * scorePerSecond);
    }

    public int getHighScore()
    {
        return PlayerPrefs.GetInt(highScorekey);
    }

    public void updateHighScore()
    {
        if(score>prevHighScore)
        {
            PlayerPrefs.SetInt(highScorekey, score);
        }
    }
}
