﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ScoreManager : MonoBehaviour
{
    private int score;

    public Text scoreText;

    private ScoreData scoreData;

    private GameManager gameController;

    // Start is called before the first frame update
    void Start()
    {
        scoreData = gameObject.GetComponent<ScoreData>();
        gameController = gameObject.GetComponent<GameManager>();
    }

    // Update is called once per frame
    void Update()
    {
        if(gameController.isGameOver() || gameController.isPaused())
        {
            return;
        }
        scoreData.updateScore();
        scoreText.text = scoreData.getScore().ToString();
    }
}
