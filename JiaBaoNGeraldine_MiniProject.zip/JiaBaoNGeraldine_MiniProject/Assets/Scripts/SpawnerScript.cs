﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnerScript : MonoBehaviour
{
    public GameObject Obstacle;
    //public GameObject PowerUp;

    public int spawnNumber;

    public float positionY;
    // Start is called before the first frame update
    void Start()
    {
        InvokeRepeating("Spawner", 1f, 1f);
    }
    
    public void Spawner()
    {
        spawnNumber = Random.Range(1, 5);

        positionY = Random.Range(-5, 5);

        this.transform.position = new Vector3(transform.position.x, positionY, transform.position.z);

        if(spawnNumber == 1)
        {
            Instantiate(Obstacle, transform.position, transform.rotation);
        }
        //if (spawnNumber == 2)
        //{
        //    Instantiate(PowerUp, transform.position, transform.rotation);
        //}

    }
}
